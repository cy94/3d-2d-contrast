
//struct CameraTrajectoryRenderMode : public VizzerModeInterface
//{
//    void init(ml::ApplicationData& _app, AppState &_state);
//    void render();
//    void keyDown(UINT key);
//    void mouseDown(ml::MouseButtonType button);
//
//	void newScene(const string &filename);
//
//    void extractAllTrajectoriesFromSensors();
//    
//
//    string helpText() const;
//    vector< pair<string, RGBColor> > statusText() const;
//
//    ml::ApplicationData *app;
//    AppState *state;
//
//    int targetObjectIndex;
//
//    Scene activeScene;
//
//    int trajectoryIndex;
//
//    CameraTrajectory trajectory;
//
//	bool bRecordingActive;
//
//};
