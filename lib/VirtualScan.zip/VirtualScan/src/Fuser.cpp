
#include "stdafx.h"

#include "GlobalAppState.h"
#include "Fuser.h"
#include "MarchingCubes.h"


Fuser::Fuser(ml::ApplicationData& _app) : m_app(_app)
{
	
}

Fuser::~Fuser()
{

}


void Fuser::fuse(const std::string& outputFile, Scene& scene, const std::vector<Cameraf>& cameraTrajectory, bool debugOut /*= false*/)
{
	std::vector<Cameraf> cameras = cameraTrajectory;

	const float voxelSize = GlobalAppState::get().s_voxelSize;
	const float depthMin = GlobalAppState::get().s_depthMin;
	const float depthMax = GlobalAppState::get().s_depthMax;
	const unsigned int maxVoxelSamples = GlobalAppState::get().s_maxVoxelSamples;

	const unsigned int imageWidth = GlobalAppState::get().s_imageWidth;
	const unsigned int imageHeight = GlobalAppState::get().s_imageHeight;

	std::vector<DXGI_FORMAT> formats = {DXGI_FORMAT_R32G32B32A32_FLOAT};
	m_renderTarget.load(m_app.graphics.castD3D11(), imageWidth, imageHeight, formats);

	for (auto& c : cameras) {
		c.updateAspectRatio((float)imageWidth / imageHeight);
	}

	//PointCloudf pc;
	BoundingBox3f bounds;
	for (size_t i = 0; i < cameras.size(); i++) {
		const auto& c = cameras[i];

		DepthImage32 depth;
		renderDepth(scene, c, depth);

		mat4f projToCamera = c.getPerspective().getInverse();
		mat4f cameraToWorld = c.getCamera().getInverse();		
		mat4f projToWorld = cameraToWorld * projToCamera;

		for (auto &p : depth) {
			if (p.value != 0.0f && p.value != 1.0f) {

				vec3f posProj = vec3f(m_app.graphics.castD3D11().pixelToNDC(vec2i((int)p.x, (int)p.y), depth.getWidth(), depth.getHeight()), p.value);
				vec3f posCamera = projToCamera * posProj;

				if (posCamera.z >= depthMin && posCamera.z <= depthMax) {
					vec3f posWorld = cameraToWorld * posCamera;
					bounds.include(posWorld);
					//pc.m_points.push_back(posWorld);
					//pc.m_colors.push_back(vec4f(color(p.x, p.y))/255.0f);
				}
			}
		}

		//std::cout << "frame " << i << " out of " << cameras.size() << " done! " << std::endl;
	}

	//PointCloudIOf::saveToFile("dump/pointcloud.ply", pc);	
	//std::cout << "scene bounds" << bounds << std::endl;
	//std::cout << "bounds extent " << bounds.getExtent() << std::endl;

	bounds.scale(1.0f + voxelSize*5.0f);
	vec3ul voxelDim = math::ceil(bounds.getExtent() / voxelSize);
	mat4f worldToGrid = mat4f::translation(-bounds.getMin());

	size_t estimatedMemory = voxelDim.x * voxelDim.y * voxelDim.z * sizeof(Voxel);
	//std::cout << "voxelGrid dimens " << voxelDim << std::endl;
	//std::cout << "voxelGrid memory " << (double)estimatedMemory / (double)(1024 * 1024 * 1024) << " GB" << std::endl;

	VoxelGrid* grid = new VoxelGrid(voxelDim, worldToGrid, voxelSize, depthMin, depthMax);


	//PointCloudf pc;
	for (size_t i = 0; i < cameras.size(); i++) {
		const auto& c = cameras[i];

		DepthImage32 depth;
		renderDepth(scene, c, depth);

		mat4f projToCamera = c.getPerspective().getInverse();
		mat4f cameraToWorld = c.getCamera().getInverse();
		mat4f projToWorld = cameraToWorld * projToCamera;
		mat4f intrinsic = Cameraf::graphicsToVisionProj(c.getPerspective(), depth.getWidth(), depth.getHeight());

		for (auto &p : depth) {
			if (p.value != 0.0f && p.value != 1.0f) {
				vec3f posProj = vec3f(m_app.graphics.castD3D11().pixelToNDC(vec2i((int)p.x, (int)p.y), depth.getWidth(), depth.getHeight()), p.value);
				vec3f posCamera = projToCamera * posProj;
				
				if (posCamera.z >= depthMin && posCamera.z <= depthMax) {
					p.value = posCamera.z;
				} else {
					p.value = 0.0f;
				}
			} else {
				p.value = 0.0f;
			}
		}
		grid->integrate(intrinsic, cameraToWorld, depth);		
		//std::cout << "integrating frame " << i << " done!" << std::endl;
	}

	SAFE_DELETE(grid);
}


void Fuser::render(Scene& scene, const Cameraf& camera, ColorImageR32G32B32A32& color, DepthImage32& depth)
{
#pragma omp critical 
		{
			auto &g = m_app.graphics.castD3D11();

			m_renderTarget.bind();
			m_renderTarget.clear(ml::vec4f(1.0f, 0.0f, 1.0f, 0.0f));

			scene.render(camera);

			m_renderTarget.unbind();

			m_renderTarget.captureColorBuffer(color);
			m_renderTarget.captureDepthBuffer(depth);
		}
}

void Fuser::renderDepth(Scene& scene, const Cameraf& camera, DepthImage32& depth)
{
#pragma omp critical 
		{
			auto &g = m_app.graphics.castD3D11();

			m_renderTarget.bind();
			m_renderTarget.clear(ml::vec4f(1.0f, 0.0f, 1.0f, 0.0f));

			scene.render(camera);

			m_renderTarget.unbind();

			m_renderTarget.captureDepthBuffer(depth);
		}
}
