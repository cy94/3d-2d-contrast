

#include "stdafx.h"
#include "Lighting.h"