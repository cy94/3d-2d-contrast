#pragma once

#include "GlobalAppState.h"
#include "Lighting.h"

class RenderObject {
public:
	RenderObject(GraphicsDevice& g, const TriMeshf& triMesh, const Materialf& material, const mat4f& modelToWorld) {
		m_triMesh.load(g, triMesh);

		m_material = material;
		if (m_material.m_TextureFilename_Kd != "") {
			//TODO load exr
		}

		m_modelToWorld = modelToWorld;
		for (const auto& v : triMesh.getVertices())  {
			m_boundingBoxWorld.include(m_modelToWorld * v.position);
		}
	}

	~RenderObject() {

	}

	const mat4f& getModelToWorld() const {
		return m_modelToWorld;
	}

	const D3D11TriMesh& getD3D11TriMesh() const {
		return m_triMesh;
	}

	const BoundingBox3f& getBoundingBoxWorld() const {
		return m_boundingBoxWorld;
	}

	const Materialf& getMaterial() const {
		return m_material;
	}

	const bool isTextured() const {
		return m_texture.size() > 0;
	}

private:
	mat4f				m_modelToWorld;
	D3D11TriMesh		m_triMesh;
	BoundingBox3f		m_boundingBoxWorld;
	
	Materialf			m_material;
	ColorImageR8G8B8A8	m_texture;
};



class Scene
{
public:
	Scene() {

	}

	~Scene() {

	}

	void loadFromGlobaAppState(GraphicsDevice& g, const GlobalAppState& gas) {
		const std::vector<std::string> meshFilenames = gas.s_meshFilenames;
		m_graphics = &g;

		m_cbCamera.init(g);
		m_cbMaterial.init(g);
		m_lighting.loadFromGlobaAppState(g, gas);

		//TODO factor our the shader loading; ideally every object has a shader
		m_shaders.init(g);
		m_shaders.registerShader("shaders/phong.hlsl", "phong");

		for (const std::string& meshFilename : meshFilenames) {
			MeshDataf meshDataAll = MeshIOf::loadFromFile(meshFilename);
			std::vector< std::pair <MeshDataf, Materialf > > meshDataByMaterial = meshDataAll.splitByMaterial();

			for (auto& m : meshDataByMaterial) {

				MeshDataf& meshData = m.first;
				Materialf& material = m.second;

				MLIB_ASSERT(meshData.isConsistent());
				if (!meshData.isTriMesh()) {
					std::cout << "Warning mesh " << meshFilename << " contains non-tri faces (auto-converting)" << std::endl;
					//TODO this needs to work with tex coords !!!
					meshData.m_TextureCoords.clear();
					meshData.m_FaceIndicesTextureCoords.clear();
					meshData.makeTriMesh();
				}


				MLIB_ASSERT(meshData.isConsistent());
				if (meshData.m_Colors.size() == 0) meshData.m_Colors.resize(meshData.m_Vertices.size(), vec4f(1.0f, 1.0f, 1.0f, 1.0f));	//set default color if none present
				TriMeshf triMesh(meshData);
				if (!triMesh.hasNormals())	triMesh.computeNormals();

				material.m_ambient = vec4f(0.1f);

				std::string path = util::directoryFromPath(meshFilename);
				if (material.m_TextureFilename_Kd != "") material.m_TextureFilename_Kd = path + material.m_TextureFilename_Kd;
				addObject(triMesh, material);
			}

		}	

		
	}

	void addObject(const TriMeshf& triMesh, const Materialf& material, const mat4f& modelToWorld = mat4f::identity()) {
		m_objects.emplace_back(RenderObject(*m_graphics, triMesh, material, modelToWorld));
		m_boundingBox.include(m_objects.back().getBoundingBoxWorld());
	}


	void render(const Cameraf& camera) {

		m_lighting.updateAndBind(2);

		for (const RenderObject& o : m_objects) {
			ConstantBufferCamera cbCamera;
			cbCamera.worldViewProj = camera.getPerspective() * camera.getCamera() * o.getModelToWorld();
			cbCamera.world = o.getModelToWorld();
			cbCamera.eye = vec4f(camera.getEye());
			m_cbCamera.updateAndBind(cbCamera, 0);

			const Materialf material = o.getMaterial();

			ConstantBufferMaterial cbMaterial;
			cbMaterial.ambient = material.m_ambient;
			cbMaterial.diffuse = material.m_diffuse;
			cbMaterial.specular = material.m_specular;
			cbMaterial.shiny = material.m_shiny;
			m_cbMaterial.updateAndBind(cbMaterial, 1);

			m_shaders.bindShaders("phong");

			o.getD3D11TriMesh().render();
		}

	} 

	const BoundingBox3f& getBoundingBox() const {
		return m_boundingBox;
	}

	void randomizeLighting() {
		m_lighting.randomize();
	}

	const Lighting& getLighting() const {
		return m_lighting;
	}

	void setLighting(const Lighting& l) {
		m_lighting = l;
	}

private:

	struct ConstantBufferCamera {
		mat4f worldViewProj;
		mat4f world;
		vec4f eye;
	};

	struct ConstantBufferMaterial {
		vec4f ambient;
		vec4f diffuse;
		vec4f specular;
		float shiny;
		vec3f dummy;
	};


	GraphicsDevice* m_graphics;

	D3D11ShaderManager m_shaders;

	std::vector<RenderObject> m_objects;
	BoundingBox3f m_boundingBox;


	D3D11ConstantBuffer<ConstantBufferCamera>	m_cbCamera;
	D3D11ConstantBuffer<ConstantBufferMaterial> m_cbMaterial;
	Lighting m_lighting;
};

